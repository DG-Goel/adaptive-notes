export const API_BASE_URL =
  (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? 'http://127.0.0.1:8000/api/v1'

export const USE_MOCK_API =
  (import.meta.env.VITE_USE_MOCK_API as string | undefined) === 'true'

/**
 * API endpoint registry.
 * Actual mapping to the Python backend will be completed in a later phase
 * after reviewing the existing API contracts.
 */
export const endpoints = {
  health: '/health',
  // Videos
  videos: '/videos',
  video: (id: string) => `/videos/${id}`,
  // Notes
  notes: (videoId: string) => `/videos/${videoId}/notes`,
  // Quizzes
  quiz: (videoId: string) => `/videos/${videoId}/quiz`,
  // Knowledge map
  knowledgeMap: (videoId: string) => `/videos/${videoId}/knowledge-map`,
  // AI tutor
  tutor: '/tutor/chat',
} as const

export type EndpointKey = keyof typeof endpoints
