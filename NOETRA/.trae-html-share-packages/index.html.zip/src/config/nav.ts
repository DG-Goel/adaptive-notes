import type { LucideIcon } from 'lucide-react'
import {
  LayoutDashboard,
  BookOpen,
  FileText,
  Sparkles,
  BrainCircuit,
  Map,
  Library,
  Settings,
} from 'lucide-react'

export interface NavItem {
  label: string
  to: string
  icon: LucideIcon
  badge?: string | number
}

export const primaryNav: NavItem[] = [
  { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard },
  { label: 'My Lectures', to: '/library', icon: BookOpen },
  { label: 'Notes Studio', to: '/notes/sample', icon: FileText },
  { label: 'AI Tutor', to: '/tutor', icon: Sparkles },
  { label: 'Quizzes', to: '/quiz/sample', icon: BrainCircuit },
  { label: 'Knowledge Map', to: '/knowledge/sample', icon: Map },
  { label: 'Library', to: '/library', icon: Library },
]

export const secondaryNav: NavItem[] = [
  { label: 'Settings', to: '/settings', icon: Settings },
]
