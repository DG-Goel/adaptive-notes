import { Sparkles } from 'lucide-react'
import { PlaceholderPage } from './PlaceholderPage'

export function TutorPage() {
  return (
    <PlaceholderPage
      eyebrow="Conversational"
      title="AI Tutor"
      description="Ask questions, explore concepts, and get personalized explanations grounded in your lectures."
      icon={<Sparkles className="h-6 w-6" />}
    />
  )
}
