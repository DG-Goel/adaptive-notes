import { Link } from 'react-router-dom'
import { ArrowRight, Sparkles } from 'lucide-react'
import { Logo } from '@/components/common/Logo'
import { PrimaryButton } from '@/components/common/PrimaryButton'
import { GlassSculpture } from '@/components/three/GlassSculpture'

export function LandingPage() {
  return (
    <div className="relative flex min-h-screen flex-col bg-background">
      {/* Nav */}
      <header className="flex items-center justify-between px-6 py-5 sm:px-10">
        <Logo />
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#features" className="transition-colors hover:text-foreground">Features</a>
          <a href="#" className="transition-colors hover:text-foreground">Pricing</a>
          <a href="#" className="transition-colors hover:text-foreground">About</a>
        </nav>
        <Link to="/dashboard">
          <PrimaryButton size="sm">Open Studio</PrimaryButton>
        </Link>
      </header>

      {/* Hero */}
      <main className="relative flex flex-1 flex-col items-center justify-center px-6 py-16 text-center sm:px-10">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute left-1/2 top-1/4 h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-accent/10 blur-[120px]" />
        </div>

        <div className="relative z-10 mx-auto flex max-w-3xl flex-col items-center gap-6">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-xs font-medium text-muted-foreground shadow-soft">
            <Sparkles className="h-3.5 w-3.5 text-accent" />
            AI-powered video learning
          </span>

          <h1 className="font-serif text-5xl font-medium leading-[1.05] tracking-tight text-foreground sm:text-6xl md:text-7xl">
            Watch. Learn.<br />
            <span className="italic text-accent">Understand.</span>
          </h1>

          <p className="max-w-xl text-pretty text-base text-muted-foreground sm:text-lg">
            NOETRA transforms educational videos into beautiful structured notes, summaries,
            diagrams, and interactive AI tutoring — so every lecture becomes lasting knowledge.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <Link to="/dashboard">
              <PrimaryButton size="lg">
                Get started free <ArrowRight className="h-4 w-4" />
              </PrimaryButton>
            </Link>
            <Link to="/design-system">
              <PrimaryButton variant="outline" size="lg">
                View design system
              </PrimaryButton>
            </Link>
          </div>
        </div>

        {/* Hero sculpture */}
        <div className="relative z-0 mt-16 h-[320px] w-full max-w-lg sm:h-[400px]">
          <GlassSculpture variant="hero" />
        </div>
      </main>

      <footer className="px-6 py-6 text-center text-xs text-muted-foreground sm:px-10">
        © {new Date().getFullYear()} NOETRA. Crafted for learners.
      </footer>
    </div>
  )
}
