import { Library } from 'lucide-react'
import { PlaceholderPage } from './PlaceholderPage'

export function LibraryPage() {
  return (
    <PlaceholderPage
      eyebrow="Collection"
      title="Video Library"
      description="Browse and organize your lecture videos. Upload, categorize, and pick up where you left off."
      icon={<Library className="h-6 w-6" />}
    />
  )
}
