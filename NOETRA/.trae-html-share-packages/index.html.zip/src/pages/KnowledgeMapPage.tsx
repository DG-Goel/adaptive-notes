import { Map } from 'lucide-react'
import { useParams } from 'react-router-dom'
import { PlaceholderPage } from './PlaceholderPage'

export function KnowledgeMapPage() {
  const { videoId } = useParams()
  return (
    <PlaceholderPage
      eyebrow={`Knowledge · ${videoId ?? 'untitled'}`}
      title="Knowledge Map"
      description="Visualize connections between concepts and see how ideas relate across your lectures."
      icon={<Map className="h-6 w-6" />}
    />
  )
}
