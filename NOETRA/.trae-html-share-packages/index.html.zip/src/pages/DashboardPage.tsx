import { LayoutDashboard } from 'lucide-react'
import { PlaceholderPage } from './PlaceholderPage'

export function DashboardPage() {
  return (
    <PlaceholderPage
      eyebrow="Overview"
      title="Dashboard"
      description="Your personal learning command center — lectures, notes, quizzes, and progress, all in one refined space."
      icon={<LayoutDashboard className="h-6 w-6" />}
    />
  )
}
