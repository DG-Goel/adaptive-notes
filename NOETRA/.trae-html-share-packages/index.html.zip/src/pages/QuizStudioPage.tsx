import { BrainCircuit } from 'lucide-react'
import { useParams } from 'react-router-dom'
import { PlaceholderPage } from './PlaceholderPage'

export function QuizStudioPage() {
  const { videoId } = useParams()
  return (
    <PlaceholderPage
      eyebrow={`Quiz · ${videoId ?? 'untitled'}`}
      title="Quiz Studio"
      description="Auto-generated quizzes from your lectures to test and reinforce your understanding."
      icon={<BrainCircuit className="h-6 w-6" />}
    />
  )
}
