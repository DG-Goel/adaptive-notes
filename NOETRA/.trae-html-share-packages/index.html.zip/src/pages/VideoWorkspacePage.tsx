import { PlayCircle } from 'lucide-react'
import { useParams } from 'react-router-dom'
import { PlaceholderPage } from './PlaceholderPage'

export function VideoWorkspacePage() {
  const { videoId } = useParams()
  return (
    <PlaceholderPage
      eyebrow={`Lecture · ${videoId ?? 'untitled'}`}
      title="Video Workspace"
      description="Watch, annotate, and interact with your lecture in a focused, distraction-free environment."
      icon={<PlayCircle className="h-6 w-6" />}
    />
  )
}
