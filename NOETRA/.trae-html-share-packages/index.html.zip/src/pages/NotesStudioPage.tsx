import { FileText } from 'lucide-react'
import { useParams } from 'react-router-dom'
import { PlaceholderPage } from './PlaceholderPage'

export function NotesStudioPage() {
  const { videoId } = useParams()
  return (
    <PlaceholderPage
      eyebrow={`Notes · ${videoId ?? 'untitled'}`}
      title="Notes Studio"
      description="AI-generated structured notes, summaries, and visual diagrams from your lecture."
      icon={<FileText className="h-6 w-6" />}
    />
  )
}
