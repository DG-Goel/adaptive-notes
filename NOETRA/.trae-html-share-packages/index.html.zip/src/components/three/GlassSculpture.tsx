import { Suspense, useEffect, useRef, useState } from 'react'
import type { CSSProperties } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Environment, Float } from '@react-three/drei'
import * as THREE from 'three'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------------ */
/*  Static fallback shown while the 3D canvas loads or if WebGL fails  */
/* ------------------------------------------------------------------ */

function SculptureFallback({
  variant = 'hero',
  className,
}: {
  variant?: 'hero' | 'mini'
  className?: string
}) {
  const isMini = variant === 'mini'
  return (
    <div
      aria-hidden="true"
      className={cn(
        'relative flex items-center justify-center overflow-hidden rounded-full',
        isMini ? 'h-24 w-24' : 'h-full w-full',
        className,
      )}
      style={{
        background:
          'radial-gradient(circle at 30% 25%, rgba(232,116,48,0.18), transparent 55%), radial-gradient(circle at 70% 75%, rgba(214,90,22,0.12), transparent 55%), #252525',
      }}
    >
      <svg
        viewBox="0 0 200 200"
        className={cn('opacity-80', isMini ? 'h-16 w-16' : 'h-2/3 w-2/3')}
        fill="none"
      >
        <defs>
          <linearGradient id="fallback-ribbon" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#F7E7C8" />
            <stop offset="0.5" stopColor="#E8A86A" />
            <stop offset="1" stopColor="#C84A10" />
          </linearGradient>
        </defs>
        <path
          d="M100 30c40 0 60 30 60 70s-20 70-60 70-60-30-60-70 20-70 60-70Z"
          stroke="url(#fallback-ribbon)"
          strokeWidth="10"
          strokeLinecap="round"
          opacity="0.9"
        />
        <path
          d="M100 170c-40 0-60-30-60-70s20-70 60-70 60 30 60 70-20 70-60 70Z"
          stroke="#F7F4EF"
          strokeWidth="10"
          strokeLinecap="round"
          opacity="0.55"
        />
      </svg>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  The actual glass ribbon mesh                                       */
/* ------------------------------------------------------------------ */

function GlassRibbon({
  variant = 'hero',
  inView,
}: {
  variant?: 'hero' | 'mini'
  inView: boolean
}) {
  const meshRef = useRef<THREE.Mesh>(null)
  const targetX = useRef(0)
  const reduceMotion =
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches

  useFrame((state, delta) => {
    const mesh = meshRef.current
    if (!mesh) return

    // Pause rotation when offscreen for performance
    if (!inView) return

    const speed = reduceMotion ? 0 : variant === 'mini' ? 0.25 : 0.4
    mesh.rotation.y += delta * speed

    // Smooth spring-like convergence toward target tilt
    const lerpFactor = reduceMotion ? 1 : 0.06
    mesh.rotation.x = THREE.MathUtils.lerp(mesh.rotation.x, targetX.current, lerpFactor)

    // Subtle breathing scale
    if (!reduceMotion) {
      const t = state.clock.elapsedTime
      const s = 1 + Math.sin(t * 0.8) * 0.008
      mesh.scale.setScalar(s)
    }
  })

  return (
    <mesh
      ref={meshRef}
      rotation={[0.3, 0.4, 0]}
      onPointerMove={(e) => {
        if (reduceMotion) return
        targetX.current = (e.point.y / 3) * 0.4
      }}
      onPointerOut={() => {
        targetX.current = 0
      }}
    >
      <torusKnotGeometry args={[1, 0.32, 256, 48, 2, 3]} />
      <meshPhysicalMaterial
        color="#FBF3E4"
        metalness={0}
        roughness={0.04}
        transmission={0.92}
        thickness={0.6}
        ior={1.5}
        clearcoat={1}
        clearcoatRoughness={0.04}
        envMapIntensity={1.6}
        attenuationColor="#E8A86A"
        attenuationDistance={2.2}
        side={THREE.DoubleSide}
      />
    </mesh>
  )
}

/* ------------------------------------------------------------------ */
/*  Scene contents inside the Canvas                                   */
/* ------------------------------------------------------------------ */

function SculptureScene({ variant, inView }: { variant: 'hero' | 'mini'; inView: boolean }) {
  return (
    <>
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 6, 5]} intensity={1.1} color="#FFF6E8" />
      <pointLight position={[-4, 2, 3]} intensity={1.4} color="#E8A86A" />
      <pointLight position={[3, -2, -4]} intensity={0.8} color="#D65A16" />
      <spotLight
        position={[0, 8, 4]}
        angle={0.5}
        penumbra={1}
        intensity={1.2}
        color="#FFF1DC"
        castShadow={false}
      />

      <Float speed={variant === 'mini' ? 1.2 : 1.6} rotationIntensity={0.15} floatIntensity={variant === 'mini' ? 0.4 : 0.7}>
        <GlassRibbon variant={variant} inView={inView} />
      </Float>

      <Environment preset="studio" />
    </>
  )
}

/* ------------------------------------------------------------------ */
/*  Public GlassSculpture component                                    */
/* ------------------------------------------------------------------ */

export type GlassSculptureProps = {
  variant?: 'hero' | 'mini'
  className?: string
  style?: CSSProperties
}

export function GlassSculpture({ variant = 'hero', className, style }: GlassSculptureProps) {
  const [supported, setSupported] = useState<boolean | null>(null)

  useEffect(() => {
    // Detect WebGL support
    try {
      const canvas = document.createElement('canvas')
      const gl = canvas.getContext('webgl2') || canvas.getContext('webgl')
      setSupported(!!gl)
      const lose = gl?.getExtension('WEBGL_lose_context')
      if (lose) lose.loseContext()
    } catch {
      setSupported(false)
    }
  }, [])

  const containerRef = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(true)

  // Pause rendering when offscreen
  useEffect(() => {
    const el = containerRef.current
    if (!el || typeof IntersectionObserver === 'undefined') return
    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { threshold: 0 },
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  const containerClass = cn(
    'relative overflow-hidden',
    variant === 'mini' ? 'h-24 w-24' : 'h-full w-full min-h-[300px]',
    className,
  )

  if (supported === false) {
    return <SculptureFallback variant={variant} className={className} />
  }

  return (
    <div ref={containerRef} className={containerClass} style={style}>
      <Suspense fallback={<SculptureFallback variant={variant} className="absolute inset-0" />}>
        {supported && inView && (
          <Canvas
            dpr={[1, 1.75]}
            camera={{ position: [0, 0, 4.5], fov: 38 }}
            gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
            frameloop={inView ? 'always' : 'demand'}
          >
            <SculptureScene variant={variant} inView={inView} />
          </Canvas>
        )}
        {supported && !inView && <SculptureFallback variant={variant} className="absolute inset-0" />}
      </Suspense>
    </div>
  )
}
